import { createSlice } from "@reduxjs/toolkit";

const authorSlice = createSlice({
    name : 'author',
    initialState : [{
        auth_id: '',
        fname: '',
        email: '',
        status: '',
        created: ''
    }],
    reducers: {
        getAuthor(state) {
          
        },
        getAuthorbyId(state) {
          
        },
        addAuthor(state) {
          
        },
        updateAuthor(state) {
          
        },
        deleteAuthor(state) {
    
        }
      }
});

export const authorActions = authorSlice.actions;

export default authorSlice;