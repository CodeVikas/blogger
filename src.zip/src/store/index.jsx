import { configureStore } from '@reduxjs/toolkit';

import userSlice from './user-slice';
import authorSlice from './author-slice';
import catSlice from './category-slice';

const store = configureStore({
  reducer: { 
                user: userSlice.reducer, 
                author: authorSlice.reducer,
                category: catSlice.reducer
           },
});

export default store;